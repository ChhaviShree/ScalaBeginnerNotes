package part3functionprog

object whatsafunction extends App{
  //DREAM: use functions as first class elements
  //problem :OOP

  val doubler=new myFunction[Int,Int]{

  override def apply(element: Int):Int=element*2
  }
  println(doubler(2))
  //function types=Function1[A,B]
  val stringtoIntConverter=new Function1[String,Int]{
    override def apply(string:String):Int=string.toInt
  }
  println(stringtoIntConverter("3")+4)

  val adder: ((Int,Int)=>Int)=new Function2[Int,Int,Int]{
    override def apply(a:Int,b:Int): Int=a+b
  }

  //ALL SCALA FUNCTIONS ARE OBJECTS DERIVING FROM FUNCTION1,FUNCTION2,FUNCTION3
  /*
  1. a functions which takes 2 strings and concatenate them
  2.transfor the mypredicate and mytransformer into function types
  3.define a fn which takes an argument an Int and returns an another function another int
  -whats the type of this fucntion
  how to do  it
   */
  val concatenate:((String,String)=>String)=new Function2[String,String,String]{
    override def apply(v1: String, v2: String): String = v1 + v2
  }
  println(concatenate("hello","bandita"))

  val superAdder:(Int =>(Int=>Int))=new Function1[Int,Function1[Int, Int]]{
    override def apply(x:Int):Function1[Int,Int]=new Function[Int,Int]{
      override def apply(v1: Int): Int = x+v1

    }
  }
  val adder3=superAdder(3)
  println(adder3(4))
  println(superAdder(2)(8))


}
trait myFunction[A,B]{
  def apply(element:A):B
}
