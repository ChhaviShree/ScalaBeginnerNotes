package part3functionprog

object HOFSandCurries extends App{
  val superFunction:(Int,(String,(Int=>Boolean))=>Int)=>(Int=>Int)= null

  //higher order function
  //map flatmap,filter

  //function that applies a fucntion n times over a value x
  //n times(f,n,x)
  //ntimes(f,3,x)=f(f(f(x)))


  //High order Functions
  def nTimes(f:Int=>Int,n:Int,x:Int):Int=
    if(n<=0) x
    else nTimes(f,n-1,f(x))

  val plusOne=(x:Int)=>x+1
  println(nTimes(plusOne,10,1))

  //sum of parameter



    def nTimesBetter(f:Int=>Int,n:Int):(Int=>Int)=
      if (n<=0) (x:Int)=>x
      else (x:Int)=> nTimesBetter(f,n-1)(f(x))

    val plus10=nTimesBetter(plusOne,10)
    println(plus10(1))

    //curried function  :Int=>(Int=>Int)   =
    val superadder:Int=>(Int=>Int)=(x:Int)=>(y:Int)=> x+y
    val add3=superadder(3)
    println(add3(10))

    //Currying- function with multiple parameter list
    def curriedFormatter(c:String)(x:Double):String=c.format(x)
    val standardFomat:(Double=>String)=curriedFormatter(("%4.2f"))
    val preciseformat:(Double=>String)=curriedFormatter("%10.8f")

    println(standardFomat(Math.PI))
    println(preciseformat(Math.PI))

    /*
    1.Expand mylist with some methods like foreach method A=> Unit (aaply on every element of mylist)
    [1,2,3].foreach(x=>println(x))

    def foreach(f:A=>Unit):Unit=
    2.sort function((A,A)=>Int)=>mylist
    [1,2,3].sort((x,y)=> y-x)=>[3,2,1]

    def sort(compare:(A,A)=>Int):mylist[A]

    3.add zipWith(list,(A,A)=>B => mylist[B]
    [1,2,3].zipWith([4,5,6],x*y)=> [1*4,2*5,3*6]=[4,10,18]

    def ZipWith[B,C](list:Mylist[B],zip:(A,B)=>C):MyList[C]

    4.fold (curryed fn)
    fold(start)(function)=> aValue
    [1,2,3].fold(0)(x+y)=6

    def fold[B](start:B)(operator:(B,a)=>B):B
    2.
    define method toCurry(f:(Int,Int)=>Int)=>(Int=>Int=>Int)
    from Curry(f:(Int=>Int=>Int)=>(Int,Int)=>Int

    3.compose(f,g)=> x=> f(g(x))
    and then (f,g)=g{f(x))
     */

    //toCurry -a function that takes two arguments and return a value and the tocurrry return a curried version

     def toCurry(f:(Int,Int) => Int):(Int=>Int=>Int)=
        x=>y=>f(x,y)

     def fromCurry(f:(Int=>Int=>Int)):(Int,Int)=>Int=
       (x,y) => f(x) (y)

     def compose[A,B,T](f:A=>B,g:T=>A):T=>B=
       x=>f(g(x))

     def andThen[A,B,C](f:A=>B,g:B=>C):A=>C=
       x=>g(f(x))
     def superadder2:(Int=>Int=>Int)= toCurry(_+_)
     def add4=superadder2(4)
     println(add4(17))

     val simpleAdder=fromCurry(superadder)
     println(simpleAdder(4,17))

     //sum of list in HOF
     def sum_num(x:Int,y:Int):Int=x+y
     val list=List(21,2,2,5)
     def adder(f:(Int,Int)=>Int,n:Int,newList:List[Int]):Int=
       if(n<0 || newList.isEmpty ) 0
       else newList.take(n).reduce(f)

     println(adder(sum_num,list.length,list))

      val arr = List(1, 4, 5, 2)
      val adder: (Int, Int) => Int = _ + _

      def addList(arr: List[Int], f: (Int, Int) => Int, n: Int, acc: Int=0): Int = {
        if (n < 0) acc
        else addList(arr, f, n - 1, f(acc, arr(n)))
      }

  println(addList(arr, adder, arr.length - 1))


}
