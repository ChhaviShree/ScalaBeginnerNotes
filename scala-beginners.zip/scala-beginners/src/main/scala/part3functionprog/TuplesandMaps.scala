package part3functionprog

import scala.annotation.tailrec

object TuplesandMaps extends App {
  val aTuple = Tuple2(2, "hello, Scala")

  println(aTuple._1) //first element
  println(aTuple.copy(_2 = "goodbye java"))
  println(aTuple.swap)


  //maps-collection to associate key to values
  val aMap: Map[String, Int] = Map()
  val aphonebook = Map(("Jim", 555), ("daniel" -> 789)).withDefaultValue(-1)
  println(aphonebook)

  //map operation
  println(aphonebook.contains("Jim"))
  println(aphonebook("MARY"))

  //add a pairing
  val newpair = "hina" -> 890
  val newphonebook = aphonebook + newpair
  println(newphonebook)

  //functions on map, map,flatmap,filter

  println(aphonebook.map(pair => pair._1.toLowerCase -> pair._2))

  //filterkeys
  //    println(aphonebook.filterKeys(x=>x.startsWith("J")))

  //map values
  println(aphonebook.mapValues(number => number * 10))

  println(aphonebook.toList)
  println(List(("a", 2345)).toMap)
  val names = List("we", "are", "stupid", "woho")
  println(names.groupBy(name => name.charAt(0)))


  /*
  1.What will happen if I had two original entries "Jim"=> 555 and "Jim"->900
2. oversimplified socialnnetwrok
person=string
add a person to network
remove friend(mutual)
unfriend

number of friends of a person
person with most friends
how many people have no friends
if there is a social connection between two people(direct or not)

 */

  val newmap = Map(("Jim", 555), ("Jim", 955))
  println(newmap.map(pair => pair._1.toLowerCase -> pair._2)) //careful with mapping key


  def add(network: Map[String, Set[String]], person: String): Map[String, Set[String]] =
    network + (person -> Set())

  def friend(network: Map[String, Set[String]], personA: String, personB: String): Map[String, Set[String]] ={
    val friendA = network(personA)
    val friendB = network(personB)

    network + (personA -> (friendA + personB)) + (personB-> (friendB + personA))
}
  def unfriend(network: Map[String, Set[String]], personA: String, personB: String): Map[String, Set[String]] ={
     val friendA=network(personA)
     val friendB=network(personB)

    network + (personA->(friendA-personB)) + (personB-> (friendB - personA))
  }
  def remove(network:Map[String,Set[String]],person:String): Map[String,Set[String]]={
    def removeAux(friends:Set[String],networkAcc:Map[String,Set[String]]):Map[String,Set[String]]=
      if(friends.isEmpty) networkAcc
      else removeAux(friends.tail,unfriend(networkAcc,person,friends.head))

    val unfriended=removeAux(network(person),network)
    unfriended-person
  }

  val empty:Map[String,Set[String]]=Map()
  val network=add(add(empty,"Mary"),"Bob")
  println(network)

  println(friend(network,"Bob","Mary"))
//  println(unfriend(friend(network,"Bob","mary"),"Bob","mary"))
//
//  println(remove(friend(network,"bob","mary"),"bob"))

  val people=add(add(add(empty,"siri"),"lily"),"jack")
  val sirilily=friend(people,"siri","lily")
  val testNet=friend(people,"lily","jack")

  println(testNet)

  def nfriends(network:Map[String,Set[String]],person:String):Int=
    if(!network.contains(person)) 0
    else
      (network(person).size)

  println(nfriends(testNet,"lily"))

  def mostfriendsk(network: Map[String,Set[String]]):String=
    network.maxBy(pair=> pair._2.size)._1

  println(mostfriendsk(testNet))

  def npeoplewithnofriends(network:Map[String,Set[String]]):Int=
    network.count(_._2.isEmpty)

  println(npeoplewithnofriends(testNet))

  def socialConnection(network:Map[String,Set[String]],a:String,b:String):Boolean= {
    @tailrec
    def bfs(target: String, consideredpeople: Set[String], discoveredpeople: Set[String]): Boolean = {
      if (discoveredpeople.isEmpty) false
      else {
        val person = discoveredpeople.head
        if (person == target) true
        else if (consideredpeople.contains(person)) bfs(target, consideredpeople, discoveredpeople.tail)
        else bfs(target, consideredpeople + person, discoveredpeople.tail ++ network(person))
      }
    }
    bfs(b,Set(),network(a)+a)
  }
 println(socialConnection(testNet,"lily","siri"))
}

