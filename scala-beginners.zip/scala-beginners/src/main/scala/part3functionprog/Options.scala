package part3functionprog

import scala.util.Random

//an option is wrapper for value that might be absent or present
object Options extends App{
  val myfirstOption:Option[Int]=Some(4)
  val nOption:Option[Int]=None

  println(myfirstOption)
 //options are created to deal with unsafe APIs

 def unsafemethod():String=null
//
// def result=Some(unsafemethod()) //wrong

val result=Option(unsafemethod()) //Option type will do null check
println(result)  //None

//chained methods
 def backupmethod(): String="valid result"
 val chainresult=Option(unsafemethod()).orElse(Option(backupmethod()))
 println(chainresult)

 ///DEsign unsafe API
 def betterunsafemethod():Option[String]=None
 def betterbackupmethod():Option[String]=Some("valid result :)")

 val betterchainresult=betterunsafemethod()orElse(betterbackupmethod())
 println(betterchainresult)

 //functions on Options
 println(myfirstOption.isEmpty)
    println(myfirstOption.get) //unsafe -do not use this


  //map flatmap, filter
  println(myfirstOption.map(_*2))
  println(myfirstOption.filter(x=> x>10))

  println(myfirstOption.flatMap(x=> Option(x*10)))

  /*
  for comprehension
  api
  val config:Map[String,String]=Map(
  //fetched from elsewhere
  "host"-> "176.45.36.1",
  "port"-> 80
  )
  class conenction{
    def connect="Connected"
  }
  object connection{
    val random=new Random(System.nanoTime())
    def apply(host:String,port:String):Option[Connection]=
         if (random.nextBoolean()) Some(new Connection)
  else None
  }

  //try to establish a connection if u can establish a connection call connect method
   */

   val config:Map[String,String]=Map(
     "host"-> "176.45.36.1",
       "port"->"80"
   )
   class Connection {
     def connect = "Connected"
   }
   object Connection{
     val randomValue=new Random(System.nanoTime())
     def apply(host:String,port:String):Option[Connection]=
       if(randomValue.nextBoolean()) Some(new Connection)
       else None
   }
  val host=config.get("host")
  val port=config.get("port")

  //if h!=null
  //if p!=null
    //return conenction.apply(h,p)
  val connection=host.flatMap(h=> port.flatMap(p=>Connection.apply(h,p)))

  //if(c!=null){
  // return c.connect
  //return null
  val connectionstatus=connection.map(c=> c.connect)
  println(connectionstatus)
  /*
  if(status!=null)
   */
  connectionstatus.foreach(println)

  //chained calls

  config.get("host")
    .flatMap(host => config.get("port")
    .flatMap(port=> Connection(host,port))
    .map(Connection=>Connection.connect))
    .foreach(println)

  //for- comprehensions
  val forConnectionStatus=for {
    host<- config.get("host")
    port<- config.get("port")
    connection<- Connection(host,port)
  }yield connection.connect
 forConnectionStatus.foreach(println)
}
