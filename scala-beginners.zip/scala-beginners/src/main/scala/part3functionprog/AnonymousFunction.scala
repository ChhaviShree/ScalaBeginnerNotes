package part3functionprog


object AnonymousFunction extends App{
  //Anonymous function
  val doubler: Int => Int = (x) => x * 2
  //or val doubler= (x:Int) => x * 2

  //multiple params
  val adder:(Int,Int)=>Int=(a:Int,b:Int)=> a+b

  //no params
  val justDoSomething:()=> Int=()=> 3

  println(justDoSomething)//function itself
  println(justDoSomething())  // function must be called with brackets,function call


  //curly braces with lambda
  val stringtoInt=( (str:String)=>
    str.toInt
    )

  //more syntactic sugar
  val niceIncremter:Int=>Int= _ +1 //equivalent to x=>x+1
  val niceAdder:(String,Int)=>String =_+_ //equivalent to (a,b)=>a+b

 /*
 1.Mylist: replace all fucntion calls with lambdas
 2  Rewrite the "special" adder as an anonymous function
  */
 val superAdder=(x:Int) => (y:Int) => x+ y
 println(superAdder(3)(4))

}
