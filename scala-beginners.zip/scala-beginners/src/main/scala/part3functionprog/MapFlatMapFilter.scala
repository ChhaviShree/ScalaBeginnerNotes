package part3functionprog

object MapFlatMapFilter extends App{

  val list=List(1,2,3)
  println(list.head)
  println(list.tail)

  //map
  println(list.map(_+1))
  println(list.map(_+" is a number"))

  //filter
  println(list.filter(_%2==0))

  //flatMap


  val toPair=(x:Int)=>List(x,x+1)
  println(list.flatMap(toPair))

//  def toPair1(x:Int):List[Int]=
//    List(x,x+1)

  /*
  print all combinations between twolist
  num=(1,2,3,4,5,5)
  char=('a,'b','c')
  list("a1","a2","a3)
   */

  val num=List(1,2,3,4,5,6)
  val charlist=List('a','b','c')
  val colors=List("black","white")

  val combination=num.flatMap(n=> charlist.map(_+ ""+n))
  println(combination)

  //for each
  list.foreach(println)
  // for -comprehensions

  val forCombinations=for {
    n <- num if n % 2 == 0
    c <- charlist
    color <- colors
  }yield "" +c + n+"-"+color
   println(forCombinations)

   for {
     n <- num
   }  println(n)

   //syntax overload

   list.map{ x=>
     x*2
   }
   /*
   1/mylist supports for comprehensions
   2.Implement small collection of at most one element- Maybe[+T]
   -> map,filter,flatmap
    */

  
}
