package part3functionprog

import java.util
import scala.util.Random

object Sequences extends App{
  //Seq

  val aSequence=Seq(1,2,3,4,5)
  println(aSequence)

  println(aSequence.reverse)
  println(aSequence(2))//apply retrives value at particular index
  println((aSequence ++ Seq(8,6,7)).sorted)
  println(aSequence.sorted)

  //Ranges
  val aRange:Seq[Int]= 1 until 10// doesnt take last value use 1 to 10
  aRange.foreach(println)

  (1 to 10).foreach(x=>println("hello ji"))

  //List
  val alist=List(1,2,3,4,5)
  val prepended=42:: alist //same work if 42 +: aList :+89
  println(prepended)

  val apple5=List.fill(5)("apple")
  println(apple5)

  println(alist.mkString("-")) //1-2-3-4-5

  //Arrays
  val numbers=Array(1,2,3,4,5,6,7)
  val treele=Array.ofDim[Int](3)
  println(numbers) //[I@6a024a67
  println(treele) //[I@7921b0a2
  treele.foreach(println) //  0 \n 0\n 0\n
  //mutation
  numbers(2)=0 //syntax sugar for numbers.update(2,0)
  println(numbers.mkString(" "))

  //arrays ad sequences
  val numberSeq:Seq[Int]=numbers //implicit conversion
  println(numberSeq)

  //vectors
  val vector:Vector[Int]=Vector(1,2,4)
  println(vector)

  //vector vs list
  def maxRuns=1000
  val maxCapacity=1000000
  def getWriteTime(collection: Seq[Int]):Double={
    val r=new Random
    val times=for{
      iteration <- 1 to maxRuns
    }yield {
      val currenttime=System.nanoTime()
      //operation
      collection.updated(r.nextInt(maxCapacity),r.nextInt())
      System.nanoTime()-currenttime
    }
    times.sum*1.0/maxRuns
  }
  val numberslist=(1 to maxCapacity).toList
  val numbersvector=(1 to maxCapacity).toVector

  //keep reference to tail
  println(getWriteTime(numberslist))//disad-middle updation takes long
  //depth of tree is small
  println(getWriteTime(numbersvector))//disad-need to replace an entire 32 element chunk

}
