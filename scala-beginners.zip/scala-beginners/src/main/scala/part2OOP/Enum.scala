package part2OOP

import part2OOP.Enum.permissions.{NONE, READ}

object Enum {
  enum permissions{
    case READ,WRITE,EXECUTE,NONE

    //add fields/methods
    def openDocument():Unit={
      if(this==READ) println("opening document")
      else println("reading not allowed")
    }
  }
  val somePermissions:permissions=NONE

  //constructor args
  enum permissionWithBits(bits:Int){
    case READ extends permissionWithBits(4)
  }
  object permissionWithBits{
    def frombits(bits:Int):permissionWithBits={
      permissionWithBits.READ
    }
  }

  //standard API
  val somePermissionsOrdinal=somePermissions.ordinal
  val allpermissions=permissionWithBits.values
  val readpermission:permissions=permissions.valueOf("READ")

  def main(args:Array[String]):Unit={
    somePermissions.openDocument()
  }
}
