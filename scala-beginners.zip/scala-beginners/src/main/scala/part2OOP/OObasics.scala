package part2OOP

object OObasics extends App{
  val person=new Person("tom",23)
  println(person.age)
  person.greet("chhavi")
  person.greet()

  val writer = new Writer("CHHAVI", "SHREE", 2012)
  writer.fullName()

  val novel = new Novel("live", 2019,writer)
  novel.authorAge()
  novel.iswrittenby()

  val novel2=new Novel("live", 2020,writer)
  novel2.copy()

  val count=new Counter(5)
  count.currentCount()
  count.incrementCount().currentCount()
  count.decrementCount().currentCount()
  count.incrementCount(4).currentCount()
  count.decrementCount(1).currentCount()


//class Person(name:String,age:Int) //construtor we cannot access age with (.)
//class parameters are not felds

//to do this use

// you need to add val to use person.age
class Person(name:String, val age:Int){
  val x=2 //we an use x as field ex person.x output will be 2
  println(1+3)

  def greet(name:String):Unit=println(s"${this.name} says: Hi $name")

  //overloading is allowed in Scala (same name different parameters)
  def greet():Unit=println(s"Hi ,I am $name")

  //multiple constructors
  def this(name:String)=this(name,0)
  def this()=this("john doe")
  }

  //to use this u have to specify [[class Person(name:String, val age:Int=0)]]

 /*EX. NOVEL AND WRITER Class
  WRITER SHOULD HAVE FIRSTNAME,SURNAME,YEAR
 -METHOD FULLNAME
  NOVEL:NAME YEAROF RELAEASE,AUTHOR
  AUTHOR AGE(METHOD)
  ISWRITTENBY(AUTHOR)
  COPY(NEW YEAR OF RELEASE)=NEW INSTANCE OF NOVEL*/

  class Writer(val firstname:String,surname:String,val year:Int) {
    def fullName(): Unit = {
      println(s"Fullname is ${this.firstname} ${this.surname}")
    }
  }

  class Novel(name:String,yearofrelease:Int,author:Writer) {
    def authorAge(): Unit = {
      println(s"author age is ${this.yearofrelease-author.year}")
    }
    def iswrittenby(): Unit = {
      println(s"author name is ${this.author.firstname}")
    }
    def copy(): Unit = {
      println(s"new year is $yearofrelease")
    }
  }

  /* question 2
  Counter class
  -method current count
  -method to increment/decrement => new Counter
  -overload inc/dec to receive an amount
  */

  class Counter(val count:Int){
    def currentCount():Unit={
      println(s"Current count is ${count}")
    }
    def incrementCount():Counter={
      new Counter(this.count+1)
    }
    def decrementCount():Counter={
      new Counter(this.count-1)
    }
    def incrementCount(amount:Int):Counter={
//      if(amount<=0) this
//      else incrementCount().incrementCount(amount-1)
     new Counter(this.count+amount)
    }

    def decrementCount(amount:Int): Counter = {
      new Counter(this.count - amount)
    }
/* we can write as
* class Counter(val count:Int){
 def increment={
 * new Counter(count+1) }



}
*
* */
  }
}
