package part2OOP

object Object {
  //SCALA DOES NOT HAVE CLASS LEVEL FUNCTIONALITY ("STATIC")


  object Person { //type+its only instance
    //static/class level functionality
    val N_EYES = 2

    def canFly: Boolean = false

    //factory method
    def apply(mother: Person, father: Person): Person = new Person("Bobbie")
  }

  class Person(val name: String) {
    //instance level funcionality
  }

  //COMPANIONS
  def main(args: Array[String]): Unit = {

    println(Person.N_EYES)
    println(Person.canFly)
    // SCALA Object is singleton instance

    val mary = new Person("Mary")
    val john = new Person("john")
    println(mary == john) //true

    val bobby = Person(mary, john)
  }
  ///Scala applications=Scala object with
  //def main(args:Arrray[String]:Unit

}

