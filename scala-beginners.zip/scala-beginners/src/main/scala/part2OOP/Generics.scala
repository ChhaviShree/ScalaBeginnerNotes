package part2OOP

object Generics extends App{
    class Mylist[A] { //type parameterised
      def add(element:A): Mylist[A]= ???
    }
    //use the type A
    class MyMap[key,value]

    val listofIntegers=new Mylist[Int]
    val listofStrings=new Mylist[String]

    //generic methods
    object Mylist{
      def empty[A]:Mylist[A]= ???
    }
    val emptylistofintegers=Mylist.empty[Int]

    //variance problem

    class Animal
    class Cat extends Animal
    class Dog extends Animal

    //1. yes list[cat] extends list[Animals]=COVARIANCE  //covariance contravariance variance
    class CovariantList[+A] //+A means its covariant list
    val animal:Animal =new Cat
    val animallist : CovariantList[Animal]= new CovariantList[Cat]
    //animalList.add(new Dog) ??? hard question

    //2. No =INVARIANCE
    class Invariantlist[A]
    val invariantanimallist: Invariantlist[Animal]=new Invariantlist[Animal]

  //3. Hell No contravariance
    class Livingbeing[-A]
    val living:Livingbeing[Cat]=new Livingbeing[Animal]

//    class Cage[A >: Animal](animal:A)
//    val cage=new Cage(new Dog)

    // expand mylist to be generic


}
