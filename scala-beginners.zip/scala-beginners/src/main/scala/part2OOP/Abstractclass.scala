package part2OOP

object Abstractclass extends App{
  abstract class Animal{
    val creatureType:String="wild"
    def eat:Unit

  }//cannot be instantiated
  class Dog extends Animal{
    override val creatureType: String = "Canine"
    def eat: Unit = println("Crunch Crunch")
  }

  //traits
  trait Carnivore{
    def eat(animal: Animal): Unit
    val preferredmeal:String="fresh meal"
  }
  trait ColdBlooded
  class Crocodile extends Animal with Carnivore with ColdBlooded {
//     val creatureType: String = "croc"
     def eat:Unit=println("nomnomnom")
     def eat(animal: Animal):Unit=println(s"I m croc and i am eating ${animal.creatureType}")
  }
  val dog=new Dog
  val croc=new Crocodile
  croc.eat(dog)

  ///traits vs abstract classes
 // trait do not have constructor parameter
 ///2.multiple trait may be inherited by same class
 //we do multiple inheritance in scala with trait
 //traits are behaviour
 //abstract class="thing"
          //scala.Any-  (right side)--scala.AnyRef(java.lang.Object)(String,list,set)  ---scala.null
  
  
          
          
}
