package part2OOP

import playground.{princeCharming}

import java.util.Date

object packagingandimport extends App{
  //package object

  //for two same imports use name aliasing
  // package objects hold standalone methods/constants- one per package
}
