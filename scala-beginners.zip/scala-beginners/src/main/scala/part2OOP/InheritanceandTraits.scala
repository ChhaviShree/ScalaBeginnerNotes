package part2OOP

object Inheritance extends App{
  class Animal{
    val creatureType="wild"
    def eat=println("nomnom") //private protected

  }
  class Cat extends Animal
  val cat=new Cat

  cat.eat
  //constructors

  class Person(name:String,age:Int){
    def this(name:String)=this(name,0)
  }
  class Adult(name:String,age:Int,idcard:String) extends Person(name)

  class Dog(override val creatureType:String) extends Animal{
     override def eat ={
       super.eat //will print nnomnom from Animal
       println("crunch crunch")
     }
  }
  val dog=new Dog("k9")
  dog.eat
  //overriding
  val unknownAnimal:Animal=new Dog("k9")
  unknownAnimal.eat

  //overloading vs overriding

  //super
  //preventing overrides use final
  //use final on entire class
  //use seal the class==extend classes in this file,but prevent extension in another file(sealed keyword)

}
