package part2OOP

import java.security.PrivilegedExceptionAction

object Exception extends App {
  /*val x:String=null
  //println(x.length)
  //this ^^ will crash with NPE
 // throwing and catching exceptions

 val awierdvalue:String =throw new NullPointerException
 //throwable classes extend the throwable class
 //exception snd error are major throwabble subtypes*/

  //2. how to catch exceptions
  def getInt(withExceptions: Boolean): Int =
    if (withExceptions) throw new RuntimeException("No int for u")
    else 42

  try {
    //code might fail
    getInt(true)
  } catch {
    case e: RuntimeException => println("caught you Runtime exception")
  } finally {
    //code that will getexecuted no matter what
    println("finally :)")
    //use finally for side effects
  }
  //anyVal is value of expression

  //how to define your own exceptions
//  class MyException extends Exception
//
//  val exception = new MyException
//  throw exception

  /*
 1.crash your program with an outofmemoryerror
 2crash with stackoverflow
 3pocket calculator
    -add(x,y)
 -    multiple(x,y)
   divide subtract  throw custome exception -overflow exception if add x y exceeeds int.maxvalue underflow exception
   if subtract(sx,y) exceeds int.minvalue and math calculation exception for division by zero*/



  //out of memory
  val array=Array.ofDim[Int](Int.MaxValue)


  // stack overflow
//  def recursivecall(x: Int, y: Int): Int = {
//    2000+recursivecall(x + 1, y + 1)
//  }
//println(recursivecall(2000979997,300077899))


class overflowexception(e:String) extends Exception
class underflowexception(e:String) extends Exception
class nullexception(e:String) extends Exception
class mathcalculationexception(e:String) extends Exception

  class calculator(val x: Int, val y: Int) {
      def add(): Int = {
          val z = x + y
          if (x>0 && y>0 && z<0) throw new overflowexception("overflow")
          else if(x<0 && y<0 && z>0) throw new underflowexception("underfow")
          else x+y
      }

      def subtract(): Int = {
        val res=x-y
        if (x>0 && y<0 && res<0) throw new overflowexception("under flow")
        else if(x<0 && y>0 && res>0) throw new underflowexception("underflow")
        else x - y
      }


    def multiply(): Int= {
        val res=x*y
      if( x>0 && y>0 && res<0)  throw new overflowexception("overflow")
      else if(x<0 && y<0 && res<0) throw new overflowexception("overflow")
      else if(x<0 && y>0 && res<0 ) throw new underflowexception("underflow")
      else if(x>0 && y<0 && res>0) throw new underflowexception("underflow")
        else x*y
    }


    def divide():Int=
        if(y==0) throw new mathcalculationexception("error here cannot divide by zero")
        else x/y
  }
val num=new calculator(5,1)
println(num.add())
println(num.subtract())
println(num.multiply())
println(num.divide())
}
