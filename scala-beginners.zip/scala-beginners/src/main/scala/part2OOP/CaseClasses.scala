package part2OOP

object CaseClasses extends App{
  /*
  equals,hashcode,toString
   */

  case class Person(name:String,age:Int)

  //1.class parameters are field
  val jim=new Person("jim",34)
  println(jim.name) //wont work if case not used

  //2.sensible to tostring
  println(jim) //is equivalent to println(jim.toString)//person(jim,34)
  //if case not used it will be object printed

  //3.equals and hashcode implemented OOTB
  val jim2=new Person("jim",34)
  println(jim==jim2)

  //4.case classes have handy copy methods
  val jim3=jim.copy(age=45)
  println(jim3)

  //5 case classes has companion object
  val theperson= Person
  println(theperson)
  val newperson=Person("mary",56)
  println(newperson)
  
  //6 case classes are serializable
  //Akka
  //7 case classes are used in pattern matching(extractor patterns)
  
  case object UnitedKingdom{
    def name: String="The UK of GB"
  }//dont get companion objects
   /*
   Expand mylist-use case classes and case objects
    */
  
}
