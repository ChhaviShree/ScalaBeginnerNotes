package part2OOP

object AnonymousClass extends App{
   abstract class Animal{
     def eat:Unit
  }
   //anonymous class

   val funnyanimal:Animal=new Animal {
     override def eat: Unit = println("hahahahhaha")
   }
   //equivalent to
  //   class AnonymousClass$$anon$1 extends Animal{
  //     override def eat: Unit = println("yeyeyyeyyeye")
  //   }

   println(funnyanimal.getClass)

   class Person(name:String){
     def sayHi:Unit=println(s"Hi,my name is $name,how can i help?")
   }
   val tim=new Person("tim"){
     override def sayHi:Unit=println(s"Hi,my name is tim,how can i help?")
   }
   tim.sayHi


}
