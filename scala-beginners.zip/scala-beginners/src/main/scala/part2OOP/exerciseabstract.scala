package part2OOP

abstract class MyList[+A]{
  /*
  head=first element of list
  tail=remainder of list
  isEmpty= is this list empty

  add(int) =>new list with element aded
  to String=> a string representation of the list
   */
  def head:A
  def tail:MyList[A]
  def isEmpty:Boolean
  //def add(element:Int):MyList
  def add[B>:A] (element: B): MyList[B]
  def printelements: String
  //polymorphic call
  override def toString: String="[" + printelements + "]"

}
object Empty extends MyList[Nothing]{
  def head: Nothing = throw new NoSuchElementException
  def tail:MyList[Nothing]=throw new NoSuchElementException
  def isEmpty:Boolean=true
  //def add(element:Int):MyList=new Construct(element,Empty)
  def add[B>:Nothing](element:B):MyList[B]=new Construct(element,Empty)
  def printelements: String = " "
}
class Construct[+A](h:A,t:MyList[A]) extends MyList[A]{
  def head:A=h
  def tail:MyList[A]=t
  def isEmpty:Boolean=false
  //def add(element:Int):MyList=new Construct(element,this)
  def add [B>:A] (element:B):MyList[B]=new Construct(element,this)
  def printelements: String =
    if(t.isEmpty) "" + h.toString
    else h.toString + " "+ t.printelements
}

    trait myPredicate[-T]{
      def test(elem: T): Boolean
    }
    trait MyTransformer[-A,B]{
      def transform(elem:A):B
    }

object ListTest extends App{
  val listofIntegers:MyList[String]=new Construct("hi",new Construct("hello",new Construct("bye bye",Empty)))
  println(listofIntegers.head)
  //val list=new Construct(1,new Construct(2,new Construct(3,Empty)))
//  println(list.head)
//  println(list.add(4).tail.head)
//  println(list.toString)
}

/*
1. Generic trait My predicate[-T],method-to test to check whether method passes valid implementation
method test[T]= boolean
2.Generic trait Mytransformer[-A,B] (convert value of type A to type B)(different implementation different subclass)
3.MyList, implement functions-
-map(transformer)=>mylist
-filter(predicate)=mylist
-flatMap(transformer from A to Mylist[B])=>MyList[B]
4.class Evenpredicate extends Mypredicate[Int]
class stringtoInttransformer extends mytransformer[String,Int]

[1,2,3].map(n*2)=[2,4,6]
[1,2,3,4].filter(n%2)=[2,4]
[1,2,3].flapMap(n=>[n,n+1])=> [1,2,2,3,3,4]
 */


