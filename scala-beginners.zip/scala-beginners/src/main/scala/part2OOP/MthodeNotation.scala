package part2OOP

import scala.language.postfixOps

object MthodeNotation extends App{
  class Person(val name:String,val favouritemovie:String,val age:Int){
    def likes(movies:String):Boolean=movies==favouritemovie
    def +(person:Person):String= s"${this.name} is hanging out with ${person.name}"
    def unary_! : String =s"$name ,what  the heck??!"
    def isAlive: Boolean = true
    def apply(): String =s"Hi I am $name"


    def +(nickname:String): Person=new Person(s"$name $nickname",favouritemovie, age)
    def unary_+ :Person =new Person (name, favouritemovie, age+1)
    def learns(course:String): String= s"$name learns $course"
    def learnsscala= this learns "Scala"
    def apply(count:Int):String=s"$name watched $favouritemovie ${count} times "


  }
  val mary=new Person("mary","Inception",20)
  println(mary.likes("Inception"))
  println(mary likes "Inception") //infix notation=operator notation(syntatic sugars)
  // ,,,works with method having one parameter

  //operators in Scala
  val tom=new Person("Tom","Fight Club",10)
  println(mary + tom) // you can rename method whichever way you want it to like here u can use method name as "+"

  //ALL OPERATORS ARE METHOD
  //AKKA actors have ! ?

  //prefix notation
  val x= -1
  val i= 1.unary_-  //(-1 is equivalent to 1.unary_-)

  //unary_prefix only works with few operator ex- - +  ~ !

  println(!mary)
  println(mary.unary_!)

  //postfix notation
  println(mary.isAlive)
  //println(mary isAlive) //doubt

  //apply
  println(mary.apply())
  println(mary()) //equivalent to mary.apply()



  //QUESTIONS
  /*
  1. overload the + operator
  mary + "rockstar" => new Person "Mary(the rockstar)"

  2. add an age to person class
  add a unary + operator=>new person with age+1
  +mary=>mary with the age incrementor

  3. add a "learns " method in the person class= > "Marry learns scala"
  add learnscala method calls earns method with "Scala"
  use it in possible notation

  4.overload the apply method
  mary.apply(2) =>"Mary watched Inception 2 times"
  * */

  println((mary + "the rockstar").apply())
  println((+mary).age)
  println(mary learnsscala)
  println(mary(2)) //apply

}
