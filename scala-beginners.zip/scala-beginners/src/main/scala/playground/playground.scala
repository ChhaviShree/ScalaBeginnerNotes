package playground

object playground {
  def main(args: Array[String]): Unit = {
    println("I m ready")
  }
}
