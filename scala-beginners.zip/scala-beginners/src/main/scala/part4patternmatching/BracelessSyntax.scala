package part4patternmatching

object BracelessSyntax {

  //if expression
  val anIfExpression=if(2>3) "bigger" else "smaller"

  //can use java style for if

  //compact

  val anIfexpression3=
    if(2>3) "bigger" else "smaller"

  //scala 3
  val anIfexpression=
    if 2>3 then
      "bigger"//higher indentation than if part
    else
      "smaller"

  val anIfempression=
    if(2>3) then
      val res="bigger"
      res
    else
      val res="smaller"
      res
  val expr=if 2>3 then "bigger" else "smaller"

  //for comprehension
  val forcompr=for{
    n<-List(1,2,3,4)
    s<-List("hj","ke","oi")
  }yield s"$n$s"

  val forcompr2=
    for
      n <- List(1, 2, 3, 4)
      s <- List("hj", "ke", "oi")
    yield s"$n$s"

  def main(args:Array[String]):Unit={
    println(anIfempression)
  }

}
