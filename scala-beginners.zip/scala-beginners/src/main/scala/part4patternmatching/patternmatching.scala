package part4patternmatching

import scala.util.Random

object patternmatching extends App{

  //switch on steroid
  val random=new Random
  val x=random.nextInt(10) // nextInt(10) means any number between 0-10

  val description= x match {
    case 1=> " the one"
    case 2=> "the two"
    case 3=>" the three"
    case _ => "I am other" //_ wildcard //if no default we ll get Match error
  }
  println(x)
  println(description)

  //use cases of pattern matching
  //1.DECOMPOSE VALUES

  case class Person(name:String,age:Int)
  val bob=Person("bob",22)

  val greeting= bob match {
    case Person(n,a) if a<21 => s"Hi,my name is $n and i cant drink in Us"
    case Person(n,a) => s"Hi,my name is $n and i m $a years old"
    case _ => s"bye i m nonone"
  }
  println(bob)
  println(greeting)
  /*
  cases are matched in order
  what if no cases match
  3. type of PM expression? unified type of all the types in all the cases
 4. pattern matching really well with case classes

   */

  //PM on sealed hierarchies
  sealed class Animal{
    case class Dog(breed:String) extends Animal
    case class parrot(greeting:String) extends Animal

    val animal:Animal=Dog("Terra Nova")
    animal match {
      case Dog(someBreed) => println(s"matched a Dog of $someBreed")
    }
  }
  //match everything
  //bad way
//  val isEven= x match{
//    case n if n%2 ==0 => true
//    case _ => false
//  }

//good way
val isEven= x%2==0

/*
Exercise
  simple function using PM
  takes and Expr=> human readable form
  Sum(Number(2),Number(3))=>2+3
  Sum(Number(2),Number(3),Number(4))-> 2+3+4

 */
    trait Expr
    case class Number(n:Int) extends Expr
    case class Sum(e1:Expr,e2:Expr) extends Expr
    case class Product(e1:Expr,e2:Expr) extends Expr

     def show(e:Expr): String= e match{
       case Number(n)=> s"$n"
       case Sum(e1,e2)=> show(e1)+ "+" + show(e2)
       case Product(e1,e2) => {
         def maybeshowparanthesis(exp: Expr) = exp match {

           case Product(_, _) => show(exp)
           case Number(_) => show(exp)
           case _ => "(" + show(exp) + ")"
         }

         maybeshowparanthesis(e1) + "*" + maybeshowparanthesis(e2)
       }
     }
     println(show(Product(Sum(Number(2),Number(3)),Number(8))))
}
