package part4patternmatching

import part2OOP.{Construct, Empty, MyList}

object AllthePatterns extends App{
   // 1-constants
   val x:Any="Scala"
   val constants= x match {
     case 1 => "a number"
     case "Scala"=>"The Scala"
     case true=>"The Truth"
     case AllthePatterns=> "A singleton Object"
   }

   val matchAnything= x match{
     case _=>
   }
   val matchAvariable= x match{
     case something=> s"I ve found $something"
   }
   val aTuple=(1,2)
   val matchATuple=aTuple match {
     case (1,1) =>
     case (something,2) => s"i ve found $something"
   }

   val nestedTuple=(1,(2,3))
   val matchAnestedTuple= nestedTuple match{
     case (_,(2,v)) => s"i ve found $v"

   }
   //pms can be nested
   //4.CASE CLASSES-constructor pattern

   val alist: MyList[Int]= Construct(1,Construct(2,Empty))
//   val matchaList=alist match {
//     case Empty=>
//     case Construct(head,tail)=>
//   } // caseclasses can also be nested case cons(head,cons(subhead,subtail))

  //LIST PATTERNS
  val aStandardList=List(1,2,3,42)
  val standardListMatching=aStandardList match{
    case List(1,_,_,_) =>  //extractor advanced
    case List(1,_*)=> //list of arbitrary length
    case 1:: List()=> //infix pattern
    case List(1,2,3):+ 42=> //infix pattern
  }

  //6.TYPE SPECIFIERS
  val unknown:Any=2
  val unknownMatch= unknown match{
    case list: List[Int]=>///explicit type specifier
    case _=>
  }
  //7.name binding
//  val nameBindingMatch= alist match{
//    case nonEmptyList @ Construct(_,_)=> //use the name later(here)
//    case Construct(1,rest @ Construct(2,1))=>
//  }
//  //8. multi patterns
//  val multipattern= alist match{
//    case Empty | Construct(0,_)=> // compound pattern multi pattern
//  }
//  //9. if guards
//  val secondelementSpecial= alist match {
//    case Construct(_, Construct(specialeleemtn,_)) if specialeleemtn %2==0=>
//  }

  val numbers=List(1,2,3)
  val numbersMatch=numbers match {
    case listofStrings:List[String]=> "a list of strings" //it will look like case listofStrings:List=> for JVM
    case listofNumbers:List[Int]=> "a list of numbers"//case listofNumbers:List=> for jvm
    case _ => ""
  }
  println(numbersMatch)
  //JVM TRICK QUESTION
  
}
