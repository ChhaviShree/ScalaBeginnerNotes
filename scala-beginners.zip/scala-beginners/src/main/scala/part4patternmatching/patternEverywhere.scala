package part4patternmatching

object patternEverywhere extends App{
  try{

  }catch{
    case e:RuntimeException=>"runtime"
    case npe: NullPointerException=>"nullpointer"
    case _=>"something else"
  }
  //catches are actually matches
  /*
  try{
  }catch(e){
    e match{
  }}
   */
  val list=List(1,2,3,4)
  val even=for{
    n<- list
    if n%2==0 //?!
  }yield 10*n

  //generators are also based on pattern matching
  val tuples=List((1,2),(3,4))
  val filtertuples=for{
    (first,second)<-tuples
  }yield  first*second

  //case classes
  //operatorsc,:: operators,...

  val tuple=(1,2,3)
  val (a,b,c)=tuple
  println(b)

  //multiple value defintion based on pattern matching
  //all the power

  val head:: tail=list
  println(head)
  println(tail)
  //big idea 4
  //partial function

  val mappedlist=list.map{
    case v if v%2==0=> v + " is even"
    case 1  => "the one"
    case _=> "something else"
  }//partial function

}
