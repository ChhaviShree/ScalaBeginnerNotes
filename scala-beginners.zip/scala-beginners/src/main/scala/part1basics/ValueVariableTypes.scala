package part1basics

object ValueVariableTypes extends App{
  val x=42
  println(x)

  //vals are immutable
  //compiler can infer types
  //val x :Int =42 (can be used)

  val sString : String ="hello world"
  val anotherString="hello world again"
  println(sString)
  println(anotherString)

  val aBoolean: Boolean = false
  val aChar: Char='a'
  val anInt: Int= x
  val aShort :Short= 4613
  val lLong :Long =45678901
  val aFloat :Float= 2.0f
  val aDouble: Double= 3.14

  //Variables(mutable)

  var aVariable: Int=4
  aVariable=5 //side-effects

  //prefer vals over vars
  //compiler automatically infer types when omitted
  //all vals and vars have types







}
