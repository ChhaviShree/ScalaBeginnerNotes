package part1basics

object Defaultclass extends App{
  def trfact(n:Int,acc:Int=1):Int={
    if(n<=1) acc
    else trfact(n-1, n*acc)
    
    
  }
    val fact10=trfact(10,2)
    
    def savePicture(format:String,width:Int,height:Int):Unit=println("saving pic")
    savePicture("jpg",800,600)
    
    //first parameter cannot be defult parameter we cannot use format:String= "jpg" as parameter
    
    /*
    * 1.pass in every leading argument
    2.name the arguments
    
    can use 
    def savePicture(format:String="jpg",width:Int=234,height:Int=687):Unit=println("saving pic")
    savePicture(width=800)
    
    
    * */

}
