package part1basics

object StringOps extends App{
  val str: String= "Hello, I am learning scala"
  println(str.charAt(3))
  println(str.substring(7,11))
  println(str.split(" ").toList)
  println(str.startsWith("hello"))
  println(str.replace(" ","-"))
  println(str.toLowerCase())
  println(str.toUpperCase())
  println(str.length)

//  val aNumberString="45"
//  val aNumber=aNumberString.toInt
//  println('a' +:aNumberString:+'z')

  val aNumberString = "45"
  val aNumber = aNumberString.toInt
  println('a' + aNumberString + 'z') //:+ :+

  println(str.reverse)
  println(str.take(2)) //new

  //Scala speific String interpolators

  //S-interpolators
  val name="David"
  val age=12
  val greeting= s"Hello,my name is $name and i m $age years old"
  val another=s"hello age is $age+ 1"
  println(another)

  //F-interpolators
  val speed=12.2f
  val myth=f"$name%s can eat $speed%2.2f burgers per min"    //DOUBT
  //2 character total,minimum 2 decimal precision

  println(myth)
  val x = 12
  val s = f"$x%3d"
  println(s)

  //raw-interpolators
  println(raw"This is \n line")
  val escaped="This is \n newline"
  println(raw"$escaped")

}
