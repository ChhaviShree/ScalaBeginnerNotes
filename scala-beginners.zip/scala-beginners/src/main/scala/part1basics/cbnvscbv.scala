package part1basics

object cbnvscbv extends App{
  def calledByValue(x: Long):Unit={
    println("by Value: "+x)
    println("by Value: "+x)
  }

  def calledbyName(x: => Long):Unit={
    println("by name: " +x)
    println("by name: " +x)
  }
  calledByValue(System.nanoTime())
  calledbyName(System.nanoTime())

  //call by value
  //value is computed before call
  //same value used everywhere
  
  //call by name
  //expression is passed literally
  //expression is evaluated at every use within
  
  

}
