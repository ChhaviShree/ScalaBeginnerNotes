package part1basics

object Expressions extends  App{
  val x= 1+2 //Expression
  println(x)

  println(2+3  * 4)
  // + - * / & | ^ << >> >>> (right shift with zero extension)

  println(!(1==x))
  //! & ||

  var aVariable =2
  aVariable +=3 //also works with -= *= /=
  println(aVariable)

  // Instructions( Do) vs Expressions (VALUE)
  // IF expression
  val aCondition=true
  val aConditionedValue= if(aCondition) 5 else 3
  println(aConditionedValue)

  var i=0
  var aWhile=while(i<10){
    println(i)
    i+=1
  }

  //everything in scala is a expression

  var aWeirdvalue= (aVariable=3) //((Unit===void))
  println(aWeirdvalue)

  //sideeffects: prinltn(), whiles,reassigning

  //Code Blocks
  var aCodeBlock={
    val y=2
    val z=y+1
    if(z>2) "hello" else "goodbye" //value of codeblock is its last expressions's value
  }
  println(aVariable.getClass) //Type of variable

  val x1= 3+5
  val xIseven= x1%2==0
  val xIsodd= !xIseven
  println(xIseven)
  println(xIsodd)

  //instruction in java ,expression in scala

  // EXAMPLES
  "hello" // stringLiteral
  println("hello") //unit

  val someVlaue={
    2<3
  }
  println((someVlaue))
  val someotherValue={
    if(someVlaue) 239 else 986
    42
  }
  println(someotherValue)
}
