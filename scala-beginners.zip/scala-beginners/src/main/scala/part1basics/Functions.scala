package part1basics

object Functions extends App{
  def aFunction(a: String, b: Int): String=
    a+ " " +b
  //can do this without return type
  println(aFunction("hey",1))


  def aparameterlessFunction() : Int=42
  println(aparameterlessFunction())
  //println(aparameterlessFunction)  (works in scala2 only)

  def aRepeatedfunction(aString :String ,n:Int): String= {
    if(n==1) aString
    else aString+ aRepeatedfunction(aString,n-1)
  }

  println(aRepeatedfunction("hello",3))

  //when you need loops, use Recursion

  def afnwithsideeffect(aString: String):Unit= println(aString)

  afnwithsideeffect("hey")

  def aBigFunction(n:Int):  Int={
  def aSmallerFn(a:Int,b:Int): Int= a+b
    aSmallerFn(n,n-1)
  }

  def greetingfn(name: String, age:Int): String=
  {
    s"Hi my name is ${name} and I am ${age} years old"
  }
  println(greetingfn("chhavi",23))

  def factorialFn(n:Int): Int= {
    if(n==0) 1
    else factorialFn(n-1)*n
  }
  println(factorialFn(0))

  def fibonacciFn(n:Int): Int={
    if(n==1) 1
    else if(n==2) 1
    else fibonacciFn(n-1)+fibonacciFn(n-2)
  }
  println(fibonacciFn(6))

  def cprime(n:Int) : Boolean ={
    def check_prime(n:Int ,k:Int): Boolean={
      if(n<=1) false
      else if(n==2) true
      else if(n%k==0) false
      else check_prime(n,k-1)
    }
    check_prime(n,n-1)
  }
  println(cprime(19))

def isPrime(n:Int):Boolean= {
  def isprimeUntil(t: Int): Boolean = {
    if (t <= 1) true
    else n % t != 0 && isprimeUntil(t - 1)
  }

  isprimeUntil(n / 2)
}
println(isPrime(19))


  def succ(c:Int)=c+1
  println(succ(2))
}


