package part1basics

import scala.annotation.tailrec
import scala.jdk.Accumulator

object Recursion extends App {


  def factorialfn(n: Int): Int = {
    //   @tailrec
    def facthelper(x: Int, accumulator: Int): Int = {
      if (x <= 1) accumulator
      else facthelper(x - 1, x * accumulator) // Tail recursion
    }

    facthelper(n, 1)
  }

  println(factorialfn(5000))

  //When YOu neeed loops use Tail recursion

  //Concatenate a string n times
  // Isprime function tail recursive
  //febonacci function


  def concatenatefn(str: String, n: Int): String = {
    @tailrec
    def helper(x: Int, news: String): String = {
      if (x == 0) news
      else helper(x - 1, news + str)
    }

    helper(n, "")
  }

  println(concatenatefn("hello", 5))

  def Isprime(n: Int): Boolean = {
    def helper(x: Int, isstillprime: Boolean): Boolean = {
      if (!isstillprime) false
      else if (x <= 1) isstillprime
      else helper(x-1, n % x != 0 && isstillprime)
    }
    helper(n/2,true)
  }
println(Isprime(9))


 def fibonnaci(n:Int):Int= {
   def fiborec(i:Int,last:Int,nextlast:Int): Int={
     if (i>=n) last
     else fiborec(i+1,last+nextlast,last)
   }
   if(n<=2) 1
   else fiborec(2,1,1)
 }
   println(fibonnaci(8))
}